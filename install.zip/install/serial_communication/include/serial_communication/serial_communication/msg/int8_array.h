// generated from rosidl_generator_c/resource/idl.h.em
// with input from serial_communication:msg/Int8Array.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__INT8_ARRAY_H_
#define SERIAL_COMMUNICATION__MSG__INT8_ARRAY_H_

#include "serial_communication/msg/detail/int8_array__struct.h"
#include "serial_communication/msg/detail/int8_array__functions.h"
#include "serial_communication/msg/detail/int8_array__type_support.h"

#endif  // SERIAL_COMMUNICATION__MSG__INT8_ARRAY_H_
