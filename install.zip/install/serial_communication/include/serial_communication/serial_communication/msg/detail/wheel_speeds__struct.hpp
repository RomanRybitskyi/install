// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_HPP_
#define SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__serial_communication__msg__WheelSpeeds __attribute__((deprecated))
#else
# define DEPRECATED__serial_communication__msg__WheelSpeeds __declspec(deprecated)
#endif

namespace serial_communication
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct WheelSpeeds_
{
  using Type = WheelSpeeds_<ContainerAllocator>;

  explicit WheelSpeeds_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->wheel_a_frequency = 0.0f;
      this->wheel_b_frequency = 0.0f;
      this->wheel_c_frequency = 0.0f;
      this->wheel_d_frequency = 0.0f;
    }
  }

  explicit WheelSpeeds_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->wheel_a_frequency = 0.0f;
      this->wheel_b_frequency = 0.0f;
      this->wheel_c_frequency = 0.0f;
      this->wheel_d_frequency = 0.0f;
    }
  }

  // field types and members
  using _wheel_a_frequency_type =
    float;
  _wheel_a_frequency_type wheel_a_frequency;
  using _wheel_b_frequency_type =
    float;
  _wheel_b_frequency_type wheel_b_frequency;
  using _wheel_c_frequency_type =
    float;
  _wheel_c_frequency_type wheel_c_frequency;
  using _wheel_d_frequency_type =
    float;
  _wheel_d_frequency_type wheel_d_frequency;

  // setters for named parameter idiom
  Type & set__wheel_a_frequency(
    const float & _arg)
  {
    this->wheel_a_frequency = _arg;
    return *this;
  }
  Type & set__wheel_b_frequency(
    const float & _arg)
  {
    this->wheel_b_frequency = _arg;
    return *this;
  }
  Type & set__wheel_c_frequency(
    const float & _arg)
  {
    this->wheel_c_frequency = _arg;
    return *this;
  }
  Type & set__wheel_d_frequency(
    const float & _arg)
  {
    this->wheel_d_frequency = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    serial_communication::msg::WheelSpeeds_<ContainerAllocator> *;
  using ConstRawPtr =
    const serial_communication::msg::WheelSpeeds_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      serial_communication::msg::WheelSpeeds_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      serial_communication::msg::WheelSpeeds_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__serial_communication__msg__WheelSpeeds
    std::shared_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__serial_communication__msg__WheelSpeeds
    std::shared_ptr<serial_communication::msg::WheelSpeeds_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const WheelSpeeds_ & other) const
  {
    if (this->wheel_a_frequency != other.wheel_a_frequency) {
      return false;
    }
    if (this->wheel_b_frequency != other.wheel_b_frequency) {
      return false;
    }
    if (this->wheel_c_frequency != other.wheel_c_frequency) {
      return false;
    }
    if (this->wheel_d_frequency != other.wheel_d_frequency) {
      return false;
    }
    return true;
  }
  bool operator!=(const WheelSpeeds_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct WheelSpeeds_

// alias to use template instance with default allocator
using WheelSpeeds =
  serial_communication::msg::WheelSpeeds_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace serial_communication

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_HPP_
