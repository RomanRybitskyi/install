// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_H_
#define SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/WheelSpeeds in the package serial_communication.
typedef struct serial_communication__msg__WheelSpeeds
{
  float wheel_a_frequency;
  float wheel_b_frequency;
  float wheel_c_frequency;
  float wheel_d_frequency;
} serial_communication__msg__WheelSpeeds;

// Struct for a sequence of serial_communication__msg__WheelSpeeds.
typedef struct serial_communication__msg__WheelSpeeds__Sequence
{
  serial_communication__msg__WheelSpeeds * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} serial_communication__msg__WheelSpeeds__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__STRUCT_H_
