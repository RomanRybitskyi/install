// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from serial_communication:msg/Int8Array.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__STRUCT_H_
#define SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/Int8Array in the package serial_communication.
typedef struct serial_communication__msg__Int8Array
{
  rosidl_runtime_c__uint8__Sequence data;
} serial_communication__msg__Int8Array;

// Struct for a sequence of serial_communication__msg__Int8Array.
typedef struct serial_communication__msg__Int8Array__Sequence
{
  serial_communication__msg__Int8Array * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} serial_communication__msg__Int8Array__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__STRUCT_H_
