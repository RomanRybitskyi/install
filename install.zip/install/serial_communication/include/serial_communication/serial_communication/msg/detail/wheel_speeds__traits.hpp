// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__TRAITS_HPP_
#define SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "serial_communication/msg/detail/wheel_speeds__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace serial_communication
{

namespace msg
{

inline void to_flow_style_yaml(
  const WheelSpeeds & msg,
  std::ostream & out)
{
  out << "{";
  // member: wheel_a_frequency
  {
    out << "wheel_a_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_a_frequency, out);
    out << ", ";
  }

  // member: wheel_b_frequency
  {
    out << "wheel_b_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_b_frequency, out);
    out << ", ";
  }

  // member: wheel_c_frequency
  {
    out << "wheel_c_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_c_frequency, out);
    out << ", ";
  }

  // member: wheel_d_frequency
  {
    out << "wheel_d_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_d_frequency, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const WheelSpeeds & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: wheel_a_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_a_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_a_frequency, out);
    out << "\n";
  }

  // member: wheel_b_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_b_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_b_frequency, out);
    out << "\n";
  }

  // member: wheel_c_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_c_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_c_frequency, out);
    out << "\n";
  }

  // member: wheel_d_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_d_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_d_frequency, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const WheelSpeeds & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace serial_communication

namespace rosidl_generator_traits
{

[[deprecated("use serial_communication::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const serial_communication::msg::WheelSpeeds & msg,
  std::ostream & out, size_t indentation = 0)
{
  serial_communication::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use serial_communication::msg::to_yaml() instead")]]
inline std::string to_yaml(const serial_communication::msg::WheelSpeeds & msg)
{
  return serial_communication::msg::to_yaml(msg);
}

template<>
inline const char * data_type<serial_communication::msg::WheelSpeeds>()
{
  return "serial_communication::msg::WheelSpeeds";
}

template<>
inline const char * name<serial_communication::msg::WheelSpeeds>()
{
  return "serial_communication/msg/WheelSpeeds";
}

template<>
struct has_fixed_size<serial_communication::msg::WheelSpeeds>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<serial_communication::msg::WheelSpeeds>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<serial_communication::msg::WheelSpeeds>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__TRAITS_HPP_
