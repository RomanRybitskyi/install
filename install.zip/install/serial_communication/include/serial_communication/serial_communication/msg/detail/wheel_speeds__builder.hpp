// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__BUILDER_HPP_
#define SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "serial_communication/msg/detail/wheel_speeds__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace serial_communication
{

namespace msg
{

namespace builder
{

class Init_WheelSpeeds_wheel_d_frequency
{
public:
  explicit Init_WheelSpeeds_wheel_d_frequency(::serial_communication::msg::WheelSpeeds & msg)
  : msg_(msg)
  {}
  ::serial_communication::msg::WheelSpeeds wheel_d_frequency(::serial_communication::msg::WheelSpeeds::_wheel_d_frequency_type arg)
  {
    msg_.wheel_d_frequency = std::move(arg);
    return std::move(msg_);
  }

private:
  ::serial_communication::msg::WheelSpeeds msg_;
};

class Init_WheelSpeeds_wheel_c_frequency
{
public:
  explicit Init_WheelSpeeds_wheel_c_frequency(::serial_communication::msg::WheelSpeeds & msg)
  : msg_(msg)
  {}
  Init_WheelSpeeds_wheel_d_frequency wheel_c_frequency(::serial_communication::msg::WheelSpeeds::_wheel_c_frequency_type arg)
  {
    msg_.wheel_c_frequency = std::move(arg);
    return Init_WheelSpeeds_wheel_d_frequency(msg_);
  }

private:
  ::serial_communication::msg::WheelSpeeds msg_;
};

class Init_WheelSpeeds_wheel_b_frequency
{
public:
  explicit Init_WheelSpeeds_wheel_b_frequency(::serial_communication::msg::WheelSpeeds & msg)
  : msg_(msg)
  {}
  Init_WheelSpeeds_wheel_c_frequency wheel_b_frequency(::serial_communication::msg::WheelSpeeds::_wheel_b_frequency_type arg)
  {
    msg_.wheel_b_frequency = std::move(arg);
    return Init_WheelSpeeds_wheel_c_frequency(msg_);
  }

private:
  ::serial_communication::msg::WheelSpeeds msg_;
};

class Init_WheelSpeeds_wheel_a_frequency
{
public:
  Init_WheelSpeeds_wheel_a_frequency()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_WheelSpeeds_wheel_b_frequency wheel_a_frequency(::serial_communication::msg::WheelSpeeds::_wheel_a_frequency_type arg)
  {
    msg_.wheel_a_frequency = std::move(arg);
    return Init_WheelSpeeds_wheel_b_frequency(msg_);
  }

private:
  ::serial_communication::msg::WheelSpeeds msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::serial_communication::msg::WheelSpeeds>()
{
  return serial_communication::msg::builder::Init_WheelSpeeds_wheel_a_frequency();
}

}  // namespace serial_communication

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__WHEEL_SPEEDS__BUILDER_HPP_
