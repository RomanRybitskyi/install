// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice
#include "serial_communication/msg/detail/wheel_speeds__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
serial_communication__msg__WheelSpeeds__init(serial_communication__msg__WheelSpeeds * msg)
{
  if (!msg) {
    return false;
  }
  // wheel_a_frequency
  // wheel_b_frequency
  // wheel_c_frequency
  // wheel_d_frequency
  return true;
}

void
serial_communication__msg__WheelSpeeds__fini(serial_communication__msg__WheelSpeeds * msg)
{
  if (!msg) {
    return;
  }
  // wheel_a_frequency
  // wheel_b_frequency
  // wheel_c_frequency
  // wheel_d_frequency
}

bool
serial_communication__msg__WheelSpeeds__are_equal(const serial_communication__msg__WheelSpeeds * lhs, const serial_communication__msg__WheelSpeeds * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // wheel_a_frequency
  if (lhs->wheel_a_frequency != rhs->wheel_a_frequency) {
    return false;
  }
  // wheel_b_frequency
  if (lhs->wheel_b_frequency != rhs->wheel_b_frequency) {
    return false;
  }
  // wheel_c_frequency
  if (lhs->wheel_c_frequency != rhs->wheel_c_frequency) {
    return false;
  }
  // wheel_d_frequency
  if (lhs->wheel_d_frequency != rhs->wheel_d_frequency) {
    return false;
  }
  return true;
}

bool
serial_communication__msg__WheelSpeeds__copy(
  const serial_communication__msg__WheelSpeeds * input,
  serial_communication__msg__WheelSpeeds * output)
{
  if (!input || !output) {
    return false;
  }
  // wheel_a_frequency
  output->wheel_a_frequency = input->wheel_a_frequency;
  // wheel_b_frequency
  output->wheel_b_frequency = input->wheel_b_frequency;
  // wheel_c_frequency
  output->wheel_c_frequency = input->wheel_c_frequency;
  // wheel_d_frequency
  output->wheel_d_frequency = input->wheel_d_frequency;
  return true;
}

serial_communication__msg__WheelSpeeds *
serial_communication__msg__WheelSpeeds__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  serial_communication__msg__WheelSpeeds * msg = (serial_communication__msg__WheelSpeeds *)allocator.allocate(sizeof(serial_communication__msg__WheelSpeeds), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(serial_communication__msg__WheelSpeeds));
  bool success = serial_communication__msg__WheelSpeeds__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
serial_communication__msg__WheelSpeeds__destroy(serial_communication__msg__WheelSpeeds * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    serial_communication__msg__WheelSpeeds__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
serial_communication__msg__WheelSpeeds__Sequence__init(serial_communication__msg__WheelSpeeds__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  serial_communication__msg__WheelSpeeds * data = NULL;

  if (size) {
    data = (serial_communication__msg__WheelSpeeds *)allocator.zero_allocate(size, sizeof(serial_communication__msg__WheelSpeeds), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = serial_communication__msg__WheelSpeeds__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        serial_communication__msg__WheelSpeeds__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
serial_communication__msg__WheelSpeeds__Sequence__fini(serial_communication__msg__WheelSpeeds__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      serial_communication__msg__WheelSpeeds__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

serial_communication__msg__WheelSpeeds__Sequence *
serial_communication__msg__WheelSpeeds__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  serial_communication__msg__WheelSpeeds__Sequence * array = (serial_communication__msg__WheelSpeeds__Sequence *)allocator.allocate(sizeof(serial_communication__msg__WheelSpeeds__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = serial_communication__msg__WheelSpeeds__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
serial_communication__msg__WheelSpeeds__Sequence__destroy(serial_communication__msg__WheelSpeeds__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    serial_communication__msg__WheelSpeeds__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
serial_communication__msg__WheelSpeeds__Sequence__are_equal(const serial_communication__msg__WheelSpeeds__Sequence * lhs, const serial_communication__msg__WheelSpeeds__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!serial_communication__msg__WheelSpeeds__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
serial_communication__msg__WheelSpeeds__Sequence__copy(
  const serial_communication__msg__WheelSpeeds__Sequence * input,
  serial_communication__msg__WheelSpeeds__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(serial_communication__msg__WheelSpeeds);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    serial_communication__msg__WheelSpeeds * data =
      (serial_communication__msg__WheelSpeeds *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!serial_communication__msg__WheelSpeeds__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          serial_communication__msg__WheelSpeeds__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!serial_communication__msg__WheelSpeeds__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
