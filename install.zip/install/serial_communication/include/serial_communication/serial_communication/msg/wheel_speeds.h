// generated from rosidl_generator_c/resource/idl.h.em
// with input from serial_communication:msg/WheelSpeeds.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_H_
#define SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_H_

#include "serial_communication/msg/detail/wheel_speeds__struct.h"
#include "serial_communication/msg/detail/wheel_speeds__functions.h"
#include "serial_communication/msg/detail/wheel_speeds__type_support.h"

#endif  // SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_H_
