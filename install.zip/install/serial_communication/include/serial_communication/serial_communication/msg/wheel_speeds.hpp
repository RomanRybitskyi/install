// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_HPP_
#define SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_HPP_

#include "serial_communication/msg/detail/wheel_speeds__struct.hpp"
#include "serial_communication/msg/detail/wheel_speeds__builder.hpp"
#include "serial_communication/msg/detail/wheel_speeds__traits.hpp"

#endif  // SERIAL_COMMUNICATION__MSG__WHEEL_SPEEDS_HPP_
